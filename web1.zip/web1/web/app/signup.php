<?php
    include('../connect/connect.php');
?>
<!Doctype html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta http-equiv="refresh" content="100">
        <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
        <title>FINNDER</title>

        <!-- Bootstrap -->
        <!-- Custom styles for this template -->
        <link href="../css/bootstrap.min.css" rel="stylesheet">
        <link href="cssdata/signup.css" rel="stylesheet">
        <!--<link href="css/home.css" rel="stylesheet">-->

        <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]-->
          <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
          <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <!--[endif]-->
       
    </head>
    <body>
        <div class="container-fluid">
            <!--Navigation-->
            <div class="navbar-header">
                <nav class="navbar navbar-fixed-top navbar-inverse">
                    <div class="container">
                        <ul class="nav navbar-nav">
                            <li><a class="inactive" href="">USERNAME</a></li>
                            <li><a href="">HOME</a></li>
                            <li><a href="">SUPPORT</a></li>
                        </ul>
                    </div><!--End of container-->
                </nav><!--navbar-->
            </div><!--navbar-header-->
        </div><!--End of container fluid-->
        <!--sign up form-->
        <div class="container start">
            <div class="row">
                <div class="col-md-8">
                    <form class="" action="signup.php" method="post">
                        <div class="panel">
                            <div class="panel-heading">
                                <h3>Sign UP Form</h3>
                            </div>
                            <div class="panel-body">
                                <div class="form-group">
                                    <label class="" for="">First Name</label>
                                    <input type="text" class="form-control" id="" name="userFirstName" placeholder="Enter First Name" required>
                                </div>
                                <div class="form-group">
                                    <label class="" for="">Last Name</label>
                                    <input type="text" class="form-control" id="" name="userLastName" placeholder="Enter Last Name" required>
                                </div>
                                <div class="form-group">
                                    <label class="" for="">Password</label>
                                    <input type="password" class="form-control" id="" name="userPassword" placeholder="Enter Password" required>
                                </div>
                                <div class="form-group">
                                    <label class="" for="">Email</label>
                                    <input type="email" class="form-control" id="" name="userEmail" placeholder="Enter Email" required>
                                </div>
                                <div class="form-group">
                                    <label class="" for="">Address</label>
                                    <input type="text" class="form-control" id="" name="userAddress" placeholder="Enter street Address" required>
                                </div>
                                <div class="form-group">
                                    <label class="" for="">city</label>
                                    <input type="text" class="form-control" id="" name="userCity" placeholder="Enter City" required>
                                </div>
                                <div class="form-group">
                                    <label class="" for="">State</label>
                                    <input type="text" class="form-control" id="" name="userState" placeholder="Enter State" maxlength="2" required>
                                </div>
                            </div>
                            <div class="panel-footer">
                                <button class="btn btn-primary btn-default" type="submit" id="" name="userSubmit">Signup</button>
                            </div>
                        </div>
                    </form>
                    <?php
                        if(isset($_POST['userFirstName']))
                        {
                            $first =$_POST['userFirstName']; 
                            $lastname =$_POST['userLastName']; 
                            $pass =$_POST['userPassword']; 
                            $newPass = password_hash($pass, PASSWORD_DEFAULT);
                            $email =$_POST['userEmail']; 
                            $address =$_POST['userAddress']; 
                            $city =$_POST['userCity']; 
                            $state =$_POST['userState']; 
                        
                            $create_sql = "INSERT into userinfo (`userFirstName`, `userLastName`, `userPassword`, `userEmail`, `userAddress`, `userCity`, `userState`) 
                            VALUES ('$first','$lastname','$newPass','$email', '$address','$city','$state')";
                            
                            $result = $db->query($create_sql);
                            if ($result) 
                            {
                                echo "<h3 class='bg-info'>Registration made</h3>";
                                ?>
                                <button onclick="location.href = 'http://localhost/finnder'" id="" class="btn btn-success">Go TO Login</button>
                            <?php
                            }
                            else
                            {
                                echo "<h3 class='bg-info'>Error, Info Not saved </h3>";
                            }
                        }
                    ?>
                </div>
                <div class="col-md-4">
                    <img class="rounded" src="../image/hotdog.jpg" height="200"><br />
                    <img class="rounded" src="../image/salad.png" height="200"><br />
                    <img class="rounded" src="../image/fruit.jpg" height="200"><br />
                </div>
            </div>
        </div>
    </body>
</html>                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         