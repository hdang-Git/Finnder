<?php
    session_start();
    include('../connect/connect.php');

    if(isset($_POST['userEmail']) && isset($_POST['userPassword']))
    {
        $_SESSION['userEmail'] = stripslashes(htmlspecialchars($_POST['userEmail']));
        $email = $_SESSION['userEmail'];
        $first;
        $passcript;
        $passenter = $_POST['userPassword'];
        
        $check_sql = "Select userFirstName, userPassword FROM userinfo where userEmail like '$email'";
        
        $check_result = $db->query($check_sql);
        if($check_result->num_rows>0)
        {
            while(($row=$check_result->fetch_assoc()))
            {
                $_SESSION['userFirstName'] = $row['userFirstName'];
                $first = $_SESSION['userFirstName'];
                $passcript = $row['userPassword'];
            }
        }
        $result = password_verify($passenter, $passcript);
        $success = ($result) ? 'True': 'False';
        
        if($success=='True')
        {
           
?>
<!Doctype html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta http-equiv="refresh" content="100">
        <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
        <title>FINNDER</title>

        <!-- Bootstrap -->
        <!-- Custom styles for this template -->
        <link href="../css/bootstrap.min.css" rel="stylesheet">
        <link href="cssdata/home.css" rel="stylesheet">
        <!--<link href="css/home.css" rel="stylesheet">-->

        <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]-->
          <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
          <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
          <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
          <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <!--[endif]-->
       
    </head>
    <body>
        <div class="container-fluid">
            <!--Navigation-->
            <div class="navbar-header">
                <nav class="navbar navbar-fixed-top navbar-inverse">
                    <div class="container">
                        <ul class="nav navbar-nav">
                            <li><a class="inactivelink" href=""><?php echo "<b>". $_SESSION['userFirstName']."</b>"; ?></a></li>
                            <li><a href="">HOME</a></li>
                            <li><a href="">SUPPORT</a></li>
                            <li><a href="#" id="exit">lOGOUT</a></li>
                        </ul>
                    </div><!--End of container-->
                </nav><!--navbar-->
            </div><!--navbar-header-->
            <div class="container start">
              <div id="myCarousel" class="carousel slide" data-ride="carousel">
                <!-- Indicators -->
                <ol class="carousel-indicators">
                  <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
                  <li data-target="#myCarousel" data-slide-to="1"></li>
                  <li data-target="#myCarousel" data-slide-to="2"></li>
                  <li data-target="#myCarousel" data-slide-to="3"></li>
                    <li data-target="#myCarousel" data-slide-to="4"></li>
                  <li data-target="#myCarousel" data-slide-to="5"></li>
                  <li data-target="#myCarousel" data-slide-to="6"></li>
                    <li data-target="#myCarousel" data-slide-to="7"></li>
                  <li data-target="#myCarousel" data-slide-to="8"></li>
                  <li data-target="#myCarousel" data-slide-to="9"></li>
                    <li data-target="#myCarousel" data-slide-to="10"></li>
                </ol>

                <!-- Wrapper for slides -->
                <div class="carousel-inner" role="listbox">
                  <div class="item active">
                      <a href="home.html?image=chicken"><img src="../image/chicken.jpg" alt="Chania" width="460" height="345"></a>
                  </div>

                  <div class="item">
                    <a href=""><img src="../image/donut.jpg" alt="Chania" width="460" height="345"></a>
                  </div>

                  <div class="item">
                    <a href=""><img src="../image/food2.jpg" alt="Flower" width="460" height="345"></a>
                  </div>

                  <div class="item">
                    <a href=""><img src="../image/fries.jpg" alt="Flower" width="460" height="345"></a>
                  </div>
                      
                  <div class="item">
                    <a href=""><img src="../image/fruit.jpg" alt="Chania" width="460" height="345"></a>
                  </div>

                  <div class="item">
                    <a href=""><img src="../image/hotdog.jpg" alt="Flower" width="460" height="345"></a>
                  </div>

                  <div class="item">
                    <a href=""><img src="../image/mac.jpg" alt="Flower" width="460" height="345"></a>
                  </div>
                      <div class="item">
                    <a href=""><img src="../image/pizza.jpg" alt="Flower" width="460" height="345"></a>
                  </div>

                  <div class="item">
                    <a href=""><img src="../image/salad.png" alt="Flower" width="460" height="345"></a>
                  </div>
                
                <div class="item">
                    <a href=""><img src="../image/spag.jpg" alt="Flower" width="460" height="345"></a>
                  </div>
                </div>

                <!-- Left and right controls -->
                <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
                  <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
                  <span class="sr-only">Previous</span>
                </a>
                <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
                  <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
                  <span class="sr-only">Next</span>
                </a>
              </div>

            </div>
        </div><!--End of container fluid-->
        <div class="container">
            <div class="row">
                <div class="col-md-8">
                     <div><select id="locationSelect" style="width:100%;visibility:hidden"></select></div>
                    <div id="map" style="width: 100%; height: 80%"></div>
                </div>
                <div class="col-md-4">

                </div>
            </div>
        </div>
        <script type="text/javascript">
            // jQuery Document
            $(document).ready(function(){
                //If user wants to end session
                $("#exit").click(function(){
                    var exit = confirm("Are you sure you want to end the session?");
                    if(exit==true){window.location = '../index.php?logout=true';}		
                });
            });
        </script>
    </body>
</html> 
<?php
             
        }
        else{
            echo "<h3>Login not correct</h3>";
        }
    }