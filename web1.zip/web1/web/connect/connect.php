<?php
    $server = 'localhost';
    $database = 'finnder';
    $user = 'root';
    $pass = '';

    $db = new mysqli($server, $user, $pass, $database);

    if(mysqli_connect_errno())
    {
            die("<h3>Username and Password incorect</h3>");
    }
?>